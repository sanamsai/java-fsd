package SumInRange;

public class SumInRange {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int n = array.length;
        int L = 2; // Starting index of the range
        int R = 7; // Ending index of the range

        int sum = findSumInRange(array, n, L, R);
        System.out.println("Sum of elements in the range of L and R: " + sum);
    }

    public static int findSumInRange(int[] arr, int n, int L, int R) {
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range");
            return -1;
        }

        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }

        return sum;
    }
}
