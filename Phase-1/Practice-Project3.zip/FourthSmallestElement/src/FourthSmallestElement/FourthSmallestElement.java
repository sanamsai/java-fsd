package FourthSmallestElement;

import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] list = {9, 5, 1, 8, 3, 7, 2, 6, 4}; // unsorted list

        int fourthSmallest = findFourthSmallest(list);
        System.out.println("Fourth smallest element: " + fourthSmallest);
    }

    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List contains less than four elements");
            return -1;
        }

        Arrays.sort(arr); // Sort the array in ascending order
        return arr[3]; // Return the fourth element (index 3)
    }
}

