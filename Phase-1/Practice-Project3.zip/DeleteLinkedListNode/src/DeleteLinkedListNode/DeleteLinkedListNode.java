package DeleteLinkedListNode; 

public class DeleteLinkedListNode {
    private Node head;

    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public void delete(int key) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        if (head.data == key) {
            head = head.next;
            return;
        }

        Node current = head;
        Node previous = null;

        while (current != null && current.data != key) {
            previous = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Key not found in the list.");
            return;
        }

        previous.next = current.next;
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        DeleteLinkedListNode list = new DeleteLinkedListNode();

        list.delete(5); // List is empty.

        list.head = list.new Node(2);
        list.head.next = list.new Node(5);
        list.head.next.next = list.new Node(8);
        list.head.next.next.next = list.new Node(3);

        System.out.println("Original List:");
        list.display(); // 2 5 8 3

        list.delete(5);
        System.out.println("List after deleting 5:");
        list.display(); // 2 8 3

        list.delete(10); // Key not found in the list.
    }
}

