package typeCasting;

public class typeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        
		        // Implicit type casting (widening)
		        int numInt = 100;
		        double numDouble = numInt; // int is converted to double
		        System.out.println("int to double: " + numDouble);
		        
		        // Explicit type casting (narrowing)
		        double numDouble2 = 123.45;
		        int numInt2 = (int) numDouble2; // double is converted to int
		        System.out.println("double to int: " + numInt2);
		        
		        // Implicit type casting (widening)
		        int numInt3 = 456;
		        String numString = "" + numInt3; // int is converted to String
		        System.out.println("int to String: " + numString);
		        
		        // Explicit type casting (narrowing)
		        String numString2 = "789";
		        int numInt4 = Integer.parseInt(numString2); // String is converted to int
		        System.out.println("String to int: " + numInt4);
		    }
		}
