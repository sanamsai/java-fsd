package MethodJava;

public class methodJava {

	    // Method that takes no arguments and returns void
	    public static void printMessage() {
	        System.out.println("Hello, world!");
	    }

	    // Method that takes two arguments and returns their sum
	    public static int addNumbers(int num1, int num2) {
	        return num1 + num2;
	    }

	    // Main method
	    public static void main(String[] args) {
	        // Calling the printMessage method in different ways
	        printMessage(); // Directly calling the method using its name
	        methodJava.printMessage(); // Calling the method using the class name
	        methodJava obj = new methodJava();
	        obj.printMessage(); // Calling the method using an object of the class

	        // Calling the addNumbers method and verifying its implementation
	        int result = addNumbers(10, 20);
	        if (result == 30) {
	            System.out.println("The addNumbers method works correctly.");
	        } else {
	            System.out.println("The addNumbers method does not work correctly.");
	        }
	    }
	}

