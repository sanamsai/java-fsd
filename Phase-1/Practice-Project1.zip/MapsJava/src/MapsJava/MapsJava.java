package MapsJava;

import java.util.HashMap;
import java.util.Map;

public class MapsJava {

	    public static void main(String[] args) {

	        // HashMap
	        Map<String, Integer> map = new HashMap<>();
	        map.put("John", 25);
	        map.put("Mary", 30);
	        map.put("Tom", 20);
	        System.out.println("HashMap example:");
	        System.out.println(map);
	        System.out.println("Size: " + map.size());
	        System.out.println("Value associated with key 'Mary': " + map.get("Mary"));

	        // Iterate over the entries in the map
	        System.out.println("Iterating over the entries in the map:");
	        for (Map.Entry<String, Integer> entry : map.entrySet()) {
	            System.out.println(entry.getKey() + " : " + entry.getValue());
	        }

	        // Check if the map contains a key
	        System.out.println("Contains key 'John': " + map.containsKey("John"));

	        // Remove an entry from the map
	        map.remove("Tom");
	        System.out.println("After removing 'Tom':");
	        System.out.println(map);
	    }
	}
