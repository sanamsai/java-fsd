package AccessModifiers;

public class accessModifiers {
		    
		    // Private instance variable
		    private int privateVar = 10;
		    
		    // Default instance variable
		    int defaultVar = 20;
		    
		    // Protected instance variable
		    protected int protectedVar = 30;
		    
		    // Public instance variable
		    public int publicVar = 40;

		    // Private method
		    private void privateMethod() {
		        System.out.println("This is a private method.");
		    }

		    // Default method
		    void defaultMethod() {
		        System.out.println("This is a default method.");
		    }

		    // Protected method
		    protected void protectedMethod() {
		        System.out.println("This is a protected method.");
		    }

		    // Public method
		    public void publicMethod() {
		        System.out.println("This is a public method.");
		    }
		    
		    // Main method
		    public static void main(String[] args) {
		        accessModifiers obj = new accessModifiers();

		        // Accessing private variable and method
		        System.out.println("Private variable: " + obj.privateVar);
		        obj.privateMethod();

		        // Accessing default variable and method
		        System.out.println("Default variable: " + obj.defaultVar);
		        obj.defaultMethod();

		        // Accessing protected variable and method
		        System.out.println("Protected variable: " + obj.protectedVar);
		        obj.protectedMethod();

		        // Accessing public variable and method
		        System.out.println("Public variable: " + obj.publicVar);
		        obj.publicMethod();


	}

}
