package ConstructorTypes;

public class constructorTypes {
	    
	    private int num1;
	    private int num2;

	    // Default constructor
	    public constructorTypes() {
	        this.num1 = 0;
	        this.num2 = 0;
	    }

	    // Parameterized constructor
	    public constructorTypes(int num1, int num2) {
	        this.num1 = num1;
	        this.num2 = num2;
	    }

	    // Copy constructor
	    public constructorTypes(constructorTypes obj) {
	        this.num1 = obj.num1;
	        this.num2 = obj.num2;
	    }

	    // Getter methods
	    public int getNum1() {
	        return this.num1;
	    }

	    public int getNum2() {
	        return this.num2;
	    }

	    // Main method
	    public static void main(String[] args) {
	        // Creating objects using different types of constructors
	    	constructorTypes obj1 = new constructorTypes();
	    	constructorTypes obj2 = new constructorTypes(10, 20);
	    	constructorTypes obj3 = new constructorTypes(obj2);

	        // Verifying the implementations of the constructors
	        if (obj1.getNum1() == 0 && obj1.getNum2() == 0) {
	            System.out.println("Default constructor works correctly.");
	        } else {
	            System.out.println("Default constructor does not work correctly.");
	        }

	        if (obj2.getNum1() == 10 && obj2.getNum2() == 20) {
	            System.out.println("Parameterized constructor works correctly.");
	        } else {
	            System.out.println("Parameterized constructor does not work correctly.");
	        }

	        if (obj3.getNum1() == 10 && obj3.getNum2() == 20) {
	            System.out.println("Copy constructor works correctly.");
	        } else {
	            System.out.println("Copy constructor does not work correctly.");
	        }
	    }
	}
