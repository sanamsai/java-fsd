package InnerClasses;


public class OuterClass {

    // Define a private instance variable for the outer class
    private int outerNum = 10;

    // Define a method for the outer class
    public void outerMethod() {
        System.out.println("Outer method");
    }

    // Define an inner class
    public class InnerClass {
        // Define a private instance variable for the inner class
        private int innerNum = 20;

        // Define a method for the inner class
        public void innerMethod() {
            System.out.println("Inner method");
            // Access the outer class instance variable from the inner class
            System.out.println("Accessing outer class variable: " + outerNum);
            // Call the outer class method from the inner class
            outerMethod();
        }
    }

    // Define a main method to run the program
    public static void main(String[] args) {
        // Create an instance of the outer class
        OuterClass outer = new OuterClass();
        // Use the outer class instance to create an instance of the inner class
        OuterClass.InnerClass inner = outer.new InnerClass();
        // Call the inner class method
        inner.innerMethod();
    }
}


