package CollectionsTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;


public class CollectionsTypes {

	    public static void main(String[] args) {

	        // ArrayList example
	        ArrayList<String> arrayList = new ArrayList<>();
	        arrayList.add("John");
	        arrayList.add("Mary");
	        arrayList.add("Tom");
	        System.out.println("ArrayList example:");
	        System.out.println(arrayList);
	        System.out.println("Size: " + arrayList.size());
	        System.out.println("Element at index 1: " + arrayList.get(1));

	        // HashMap example
	        HashMap<Integer, String> hashMap = new HashMap<>();
	        hashMap.put(1, "Apple");
	        hashMap.put(2, "Banana");
	        hashMap.put(3, "Orange");
	        System.out.println("HashMap example:");
	        System.out.println(hashMap);
	        System.out.println("Size: " + hashMap.size());
	        System.out.println("Value associated with key 2: " + hashMap.get(2));

	        // HashSet example
	        HashSet<String> hashSet = new HashSet<>();
	        hashSet.add("Dog");
	        hashSet.add("Cat");
	        hashSet.add("Fish");
	        System.out.println("HashSet example:");
	        System.out.println(hashSet);
	        System.out.println("Size: " + hashSet.size());
	        System.out.println("Contains 'Dog': " + hashSet.contains("Dog"));
	    }
	}
