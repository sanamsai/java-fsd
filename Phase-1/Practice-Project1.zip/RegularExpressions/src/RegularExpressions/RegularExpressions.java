package RegularExpressions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressions {

	    public static void main(String[] args) {
	        // Create a pattern to match the word "hello"
	        Pattern pattern = Pattern.compile("hello");

	        // Create a matcher to search for the pattern in a string
	        String text = "Hello world!";
	        Matcher matcher = pattern.matcher(text);

	        // Find the first occurrence of the pattern in the string
	        if (matcher.find()) {
	            System.out.println("Found the pattern in the text!");
	        } else {
	            System.out.println("Pattern not found in the text.");
	        }

	        // Replace all occurrences of the pattern in the string
	        String replacedText = matcher.replaceAll("hi");
	        System.out.println("Replaced text: " + replacedText);

	        // Create a pattern to match an email address
	        pattern = Pattern.compile("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");

	        // Create a matcher to search for the pattern in a string
	        text = "My email is john.doe@example.com. What is yours?";
	        matcher = pattern.matcher(text);

	        // Find all occurrences of the pattern in the string
	        while (matcher.find()) {
	            System.out.println("Found email: " + matcher.group());
	        }
	    }

	}
