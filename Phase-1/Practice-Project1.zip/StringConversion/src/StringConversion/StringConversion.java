package StringConversion;

public class StringConversion {

	    public static void main(String[] args) {
	        // Create a string
	        String str = "Hello, world!";

	        // Convert string to StringBuffer
	        StringBuffer sb = new StringBuffer(str);

	        // Append some text to the StringBuffer
	        sb.append(" Welcome to Java!");

	        // Print the StringBuffer
	        System.out.println("StringBuffer: " + sb);

	        // Convert string to StringBuilder
	        StringBuilder sbd = new StringBuilder(str);

	        // Append some text to the StringBuilder
	        sbd.append(" Enjoy coding!");

	        // Print the StringBuilder
	        System.out.println("StringBuilder: " + sbd);
	    }

	}
