public class ExponentialSearch {

    public static int exponentialSearch(int[] array, int target) {
        if (array[0] == target) {
            return 0; // Return index 0 if target is found at the first position
        }

        int bound = 1;
        while (bound < array.length && array[bound] <= target) {
            bound *= 2; // Double the bound
        }

        return binarySearch(array, target, bound / 2, Math.min(bound, array.length - 1));
    }

    public static int binarySearch(int[] array, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (array[mid] == target) {
                return mid; // Return the index if target is found
            }

            if (array[mid] < target) {
                left = mid + 1; // Discard the left half
            } else {
                right = mid - 1; // Discard the right half
            }
        }

        return -1; // Return -1 if target is not found
    }

    public static void main(String[] args) {
        int[] array = { 1, 2, 5, 7, 9 };

        int target = 2;
        int index = exponentialSearch(array, target);

        if (index != -1) {
            System.out.println("Target found at index: " + index);
        } else {
            System.out.println("Target not found in the array.");
        }
    }
}