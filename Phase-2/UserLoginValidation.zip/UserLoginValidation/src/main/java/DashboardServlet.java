import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("loggedIn") != null && (boolean) session.getAttribute("loggedIn")) {
            // User is logged in, show the dashboard
            response.setContentType("text/html");
            response.getWriter().println("<h2>Welcome to the Dashboard</h2>");
            response.getWriter().println("<p>This is your dashboard content.</p>");
            response.getWriter().println("<a href=\"logout\">Logout</a>");
        } else {
            // User is not logged in, redirect to the login page
            response.sendRedirect("login.html");
        }
    }
}




