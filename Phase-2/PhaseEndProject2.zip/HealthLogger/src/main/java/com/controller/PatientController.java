package com.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.dao.DB;
import com.models.AdminModel;
import com.models.PatientModel;

@WebServlet("/PatientController")
public class PatientController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    DB db = DB.getDb();

    public PatientController() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (request.getParameter("mode").equals("delete")) {
            doDelete(request, response);
            return;
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sess = request.getSession();
        AdminModel admin = (AdminModel) sess.getAttribute("admin");

        if (admin == null) {
            // Handle case when admin is not logged in
            response.sendRedirect("adminLogin.jsp"); // Redirect to the login page
            return;
        }

        if (request.getParameter("mode").equals("update")) {
            doPut(request, response);
            return;
        }

        PatientModel model = new PatientModel();
        model.name = request.getParameter("name");
        model.email = request.getParameter("email");
        model.phone = request.getParameter("phone");
        model.age = Integer.parseInt(request.getParameter("age"));
        model.diagnosis = request.getParameter("diagnosis");
        model.remarks = request.getParameter("remarks");
        model.gender = request.getParameter("gender");
        model.createdByAdminId = admin.adminId;

        int result = db.executeUpdate(model.getPatientInsertQuery());
        if (result > 0) {
            response.sendRedirect("managePatients.jsp");
        } else {
            request.setAttribute("message", "Something went wrong!! Please Try Again");
            request.getRequestDispatcher("/patientForm.jsp?mode=add").forward(request, response);
        }
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sess = request.getSession();
        AdminModel admin = (AdminModel) sess.getAttribute("admin");

        if (admin == null) {
            // Handle case when admin is not logged in
            response.sendRedirect("adminLogin.jsp"); // Redirect to the login page
            return;
        }

        PatientModel model = new PatientModel();
        model.patientId = Integer.parseInt(request.getParameter("patientId"));
        model.name = request.getParameter("name");
        model.email = request.getParameter("email");
        model.phone = request.getParameter("phone");
        model.age = Integer.parseInt(request.getParameter("age"));
        model.diagnosis = request.getParameter("diagnosis");
        model.gender = request.getParameter("gender");
        model.remarks = request.getParameter("remarks");

        int result = db.executeUpdate(model.getUpdateQuery());
        if (result > 0) {
            response.sendRedirect("managePatients.jsp");
        } else {
            request.setAttribute("message", "Something went wrong!! Please Try Again");
            response.getWriter().print("Something went wrong");
            response.getWriter().close();
            request.getRequestDispatcher("/patientForm.jsp?mode=update").forward(request, response);
        }
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int patientId = Integer.parseInt(request.getParameter("patientId"));
        db.executeUpdate(PatientModel.getDeleteQuery(patientId));
        response.sendRedirect("managePatients.jsp");
    }

}
